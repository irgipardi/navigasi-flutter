package com.example.navigasi_2006118

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
